﻿using Xamarin.Forms;
using Xamarin.Forms.Platform.WPF;
using XamarinTest.WPF.Renderers;

[assembly: ExportRenderer(typeof(Label), typeof(MyLabelRenderer))]
namespace XamarinTest.WPF.Renderers
{
    public class MyLabelRenderer : LabelRenderer
    {
        protected override void OnElementChanged(ElementChangedEventArgs<Label> e)
        {
            base.OnElementChanged(e);
            if (e.NewElement != null)
            {
                if (Control != null)
                {
                    //The default fontfamily is Microsoft YaHei UI.
                    //While my system language is chinese,the fontfamily should be 微软雅黑.
                    if (Control.FontFamily.ToString().Equals("Microsoft YaHei UI"))
                    {
                        Control.FontFamily = new System.Windows.Media.FontFamily("微软雅黑");
                    }
                }
            }
        }
    }
}
